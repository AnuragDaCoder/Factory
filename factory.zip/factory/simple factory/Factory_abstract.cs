﻿using static simple_factory.StateWiseMBBSCoachingCost;

namespace simple_factory
{
    public interface IMBBSCostDiscountFactory
    {
        ITotalCost CreateCostService();
        IDiscount CreateDiscountService();
    }

    public class StateCoachingFinalCostFactory : IMBBSCostDiscountFactory
    {
        private readonly string _stateCode;
        public StateCoachingFinalCostFactory(string stateCode)
        {
            _stateCode = stateCode;
        }
        public ITotalCost CreateCostService()
        {
            return new StateWiseMBBSCoachingCost(_stateCode);
        }

        public IDiscount CreateDiscountService()
        {
            return new StateWiseMBBSCoachingDiscount();
        }
    }

    public class CouponApplyMBBSCoachingFinalCostFactory : IMBBSCostDiscountFactory
    {
        private readonly Guid _couponCode;
        public CouponApplyMBBSCoachingFinalCostFactory(Guid couponCode)
        {
            _couponCode = couponCode;
        }
        public ITotalCost CreateCostService()
        {
            return new CouponApplyMBBSCoachingCost(_couponCode);
        }
        public IDiscount CreateDiscountService()
        {
            return new CouponApplyMBBSCoachingDiscount();
        }
    }
}


