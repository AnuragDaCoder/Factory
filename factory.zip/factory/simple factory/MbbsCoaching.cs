﻿
namespace simple_factory
{
    public class MbbsCoaching
    {
        private readonly IDiscount _discountService;
        private readonly ITotalCost _totalCostService;
        public MbbsCoaching(IMBBSCostDiscountFactory factory)
        {
            _discountService = factory.CreateDiscountService();
            _totalCostService = factory.CreateCostService();
        }

        public decimal FinalCost()
        {
            return _totalCostService.TotalCost - _discountService.Discount;
        }
    }
}


