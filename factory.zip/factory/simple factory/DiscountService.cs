﻿namespace simple_factory
{
    public interface IDiscount
    {
        decimal Discount { get; }
    }

    internal class StateWiseMBBSCoachingDiscount : IDiscount
    {
        public decimal Discount => 2000;
    }
    //added newly
    internal class CouponApplyMBBSCoachingDiscount : IDiscount
    {
        public decimal Discount => 1000;
    }
}



