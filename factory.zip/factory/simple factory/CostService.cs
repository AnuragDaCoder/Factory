﻿namespace simple_factory
{
    public interface ITotalCost
    {
        decimal TotalCost { get; }
    }
    internal class StateWiseMBBSCoachingCost : ITotalCost
    {
        private readonly string _stateCode;
        public StateWiseMBBSCoachingCost(string stateCode)
        {
            _stateCode = stateCode;
        }
        public decimal TotalCost
        {
            get
            {
                switch (_stateCode)
                {
                    case "WB":
                        return 25500;
                    case "MP":
                        return 35500;
                    case "Goa":
                        return 15500;
                    default:
                        return 20000;
                }
            }
        }

        internal class CouponApplyMBBSCoachingCost : ITotalCost
        {
            private readonly Guid _couponCode;
            public CouponApplyMBBSCoachingCost(Guid couponCode)
            {
                _couponCode = couponCode;
            }
            public decimal TotalCost
            {
                get
                {
                    //check for cup
                    return 5000;
                }
            }
        }    
    }
}


