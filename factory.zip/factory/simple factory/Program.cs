﻿// See https://aka.ms/new-console-template for more information
using simple_factory;
using static simple_factory.StateWiseMBBSCoachingCost;

//ITotalCostFactory obj = new OutsideStateMBBSCoachingCostFactory("WB");
//Console.WriteLine(obj.CreateTotalCostService().TotalCost);

////creation should be separated



var factory = new CouponApplyMBBSCoachingFinalCostFactory(new Guid());
var mbbscoaching = new MbbsCoaching(factory);
Console.WriteLine(mbbscoaching.FinalCost());
