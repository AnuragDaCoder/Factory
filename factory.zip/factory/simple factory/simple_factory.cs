﻿//namespace simple_factory
//{
//    internal static class simpleFactory
//    {
//        public static ITotalCost createMBBSCoachingService(string ddownvalue)
//        {
//            switch (ddownvalue)
//            {
//                case "state":
//                    return new StateWiseMBBSCoachingCost("WB");
//                case "coupon":
//                    return new CouponApplyMBBSCoachingCost(new Guid());
//                default:
//                    return new StateWiseMBBSCoachingCost("Odisha");
//            }
//        }
//    }
//}
